﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
[RequireComponent(typeof(Text))]
public class ShowBuildVersion : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        StartCoroutine(GetMac());
    }
    void Reset()
    {
        GetComponent<Text>().text = "Build ver";
        GetComponent<Text>().raycastTarget=false;
    }
    IEnumerator GetMac()
    {

        Text text = GetComponent<Text>();

#if UNITY_ANDROID
        string url = "jar:file://" + Application.dataPath + "!/assets/" + "version.json";
#else
        string url = "file://" + System.IO.Path.Combine(Application.streamingAssetsPath, "version.json");
#endif
        //        Debug.Log("reading mac from " + url);
        var www = new WWW(url);
        yield return www;
        text.text = "Build unknown";
        if (www.error != null)
        {

            // Debug.Log("error " + www.error);
        }
        else
        {
            var buildVersion = JsonUtility.FromJson<BuildVer>(www.text);
            if (buildVersion != null)
                text.text = "Build " + buildVersion.version; ;
        }
    }
}
