﻿


#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Callbacks;
#endif
using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class BuildVer
{
    public int version;
}
#if UNITY_EDITOR
public class IncrementBuildVersion : ScriptableObject
{
static string baseBundle="10.";
    [PostProcessBuild]
    public static void OnPostProcessBuild(BuildTarget target, string buildPath)
    {
        Debug.Log("buildpostor");
        BuildVer b = null;
        b = b.FromJson("version");
        if (b == null) b = new BuildVer();
        b.version++;
         
         PlayerSettings.Android.bundleVersionCode = b.version;
         PlayerSettings.bundleVersion =baseBundle+b.version;


        b.ToJson("version");
        Debug.Log("UpdatedBuildVersion To " + b.version);
    }
}
#endif