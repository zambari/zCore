﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ITakeNormalizedFloat  {

	// float GetMaxValue();
	void SetValue(float f);
	string name {get;}
	GameObject gameObject {get;}
}
