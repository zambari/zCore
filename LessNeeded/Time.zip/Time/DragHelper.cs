﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
// v.01 ratio

[RequireComponent(typeof(Image))]
public class DragHelper : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerEnterHandler, IPointerExitHandler
{
	public enum Direction { Horizontal, Vertical, HorizontalReversed, VerticalReversed }
	public Direction direction;
	Vector2 lastPostion;
	public FloatEvent dragValue;
	[Range(1, 2000)]
	public float pixelsPerUnit = 1000;
	Image image { get { if (_image == null) _image = GetComponent<Image>(); return _image; } }
	Image _image;

	public Color normalColor = Color.red;
	public Color hoverColor = Color.red * 0.6f;
	public bool changeColor = false;
	public bool useVelo;
	void Reset()
	{
		var img = GetComponent<Image>();
		if (img != null)
		{
			normalColor = img.color;
			hoverColor = img.color / 2;

		}
	}
	public float valueScaler = 1;
	public Damper velocityDamper = new Damper(2);
	int avgCnt = 5;

	public void OnPointerEnter(PointerEventData e)
	{
		if (changeColor)
			image.color = hoverColor;

	}
	public void OnPointerExit(PointerEventData e)
	{
		if (changeColor)
			image.color = normalColor;
	}
	public void OnBeginDrag(PointerEventData e)
	{
		enabled = true;
		velocityDamper.InitializeValue(0);

		lastPostion = e.position;
		if (!changeColor)
			image.color = hoverColor;
	}
	public void OnEndDrag(PointerEventData e)
	{
		if (!changeColor)
			image.color = normalColor;
	}
	public float damping = .4f;
	float lastVeloValue;
	float veloTresh = 1;
	[ReadOnly]
	public float lastval = 0;
	void Update()
	{
		if (useVelo)
		{
			var thisVal = velocityDamper.UpdatedValue();
			if (Mathf.Abs(thisVal - lastVeloValue) <= veloTresh)
			{
				//	enabled = false;
				// Debug.Log("lovelo");
			}
			else
			{
				velocityDamper.targetValue *= (1 - Time.deltaTime * damping);
				lastval = thisVal * valueScaler;
				dragValue.Invoke(lastval);
			}
			lastVeloValue = thisVal;

		}
	}

	public void OnDrag(PointerEventData e)
	{

		float dragAmount;
		if (direction == Direction.Horizontal || direction == Direction.HorizontalReversed)
		{
			dragAmount = e.position.x - lastPostion.x;

		}
		else
			dragAmount = e.position.y - lastPostion.y;

		if (direction == Direction.HorizontalReversed || direction == Direction.VerticalReversed)
			dragAmount *= -1;

		dragAmount /= pixelsPerUnit;
		if (useVelo)
		{
			// lastVeloValue =
			velocityDamper.targetValue += dragAmount;

		}
		else
		{
			dragValue.Invoke(dragAmount * valueScaler / pixelsPerUnit);
		}
		lastPostion = e.position;
	}
	// Use this for initialization

	void Start()
	{
		//if (!useVelo) enabled = false;
	}
	void OnValidate()
	{
		image.color = normalColor;

	}

}