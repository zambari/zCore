﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Z;
public class RangeSliderController : MonoBehaviour
{

	public Slider sliderIn;
	public Slider sliderOut;
	public VoidEvent onRangeChanged=new VoidEvent();
	[Range(0, 1)]
	[SerializeField] float _rangeIn;
	[Range(0, 1)]
	[SerializeField] float _rangeOut = 1;
	public RectTransform fillImage;
	float minduration = 0.02f;
	public enum Direction { horizontal, vertical }
	public Direction direction;
	public Vector2 range
	{
		get
		{
			return new Vector2(rangeIn, rangeOut);
		}
		set
		{
			if (CheckIn(value.x) && CheckOut(value.y)) 
			{  rangeIn = value.x; rangeOut = value.y;
			  }

		}
	}
	public Vector2 GetRangeWithBuffer(float bufferScale=.1f)
	{
	return	 new Vector2(rangeIn-bufferScale, rangeOut+bufferScale);
	}
	
	public float rangeIn
	{
		get { return _rangeIn; }
		set
		{
			if (CheckIn(value))
			{
				_rangeIn = value;

				RecalculateRange();
			}
			else { Debug.Log("rangeingacld " + value); }
		}
	}

	public float rangeOut
	{
		get { return _rangeOut; }
		set
		{
			if (CheckOut(value))
			{
				_rangeOut = value;
				RecalculateRange();
			}
		}
	}
	float minRange = .015f;
	public float dragRatio = 0.001f;
	void OnValidate()
	{
		rangeIn = rangeIn;
		rangeOut = rangeOut;
	}
	float _lastIn;
	float _lastOut;
	bool CheckIn(float newVal)
	{
		if (newVal > _rangeOut - minRange || newVal < 0)
		{
			return false;
		}
		return true;
	}
	bool CheckOut(float newVal)
	{
		if (newVal < _rangeIn + minRange || newVal > 1)
		{
			return false;
		}
		return true;
	}
	void RecalculateRange()
	{
	
		if (!Application.isPlaying)
		{
			if (sliderOut != null)
				sliderOut.value = rangeOut;
			if (sliderIn != null)
				sliderIn.value = rangeIn;
		}

		if (fillImage != null)
		{
			if (direction == Direction.horizontal)
			{
				fillImage.anchorMin = new Vector2(rangeIn, 0);
				fillImage.anchorMax = new Vector2(rangeOut, 1);

			}
			else //direction vertical
			{
				fillImage.anchorMin = new Vector2(0, rangeIn);
				fillImage.anchorMax = new Vector2(1, rangeOut);
			}
		}
		
		onRangeChanged.Invoke();

	}

	void Start()
	{
	
		OnValidate();
		sliderIn.value = rangeIn;
		sliderOut.value = rangeOut;
		sliderIn.onValueChanged.AddListener((x) =>
		{
			_lastIn = x;
			rangeIn = x;

		});
		sliderOut.onValueChanged.AddListener((x) =>
		{

			_lastOut = x;
			rangeOut = x;

		});
	

	}
	public void Offset(float amt)
	{
		amt /= 100;
		if (CheckIn(rangeIn + amt) && CheckOut(rangeOut + amt))
		{
			rangeOut += amt;
			rangeIn += amt;
		}
		else
		{
		}
	}
	void Update()
	{

		if (_lastOut != rangeOut)
		{
			_lastOut = rangeOut;
			if (sliderOut != null)
				sliderOut.value = rangeOut;

		}
		if (_lastIn != rangeIn)
		{
			_lastIn = rangeIn;
			if (sliderIn != null)
				sliderIn.value = rangeIn;
		}
	}

}